<?php

include_once 'head.php';
?>
	<body>	
	
<?php

include_once 'header_cardapio.php';
?>
		
		<main role="main">		
			<div class="jumbotron sobre-empresa">
				<div class="container">
					<h2 class="display-4 text-center perg-resp-text" style="margin-bottom: 50px">Cardápio</h2>
					<div class="row featurette">
						<div class="col-md-7 order-md-2 emp-text-mod-um">
							<h2 class="featurette-heading">Pizza Principal.</h2>
							<p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
						
						 <a href="https://api.whatsapp.com/send?phone=+5587999181877&text=Oi! Gostaria de Fazer Um Pedido!!" class="btn btn-success btn-icon-split" target="_blank">
				<span class="icon text-white-50">
					<i class="fab fa-whatsapp"></i>
				</span>
				<span class="text">Pedido Por WhatsApp</span>
			   </a>
						
						</div>
						<div class="col-md-5 order-md-1 emp-img-mod-um">
							<img class="featurette-image img-fluid mx-auto" src="imagens/sob_card/1/01.jpg" alt="Prato Principal">
						
						
						
						
						</div>
					</div>
				</div>
			</div>
			
			<div class="jumbotron sobre-empresa">
				<div class="container">
					<div class="row featurette">
						<div class="col-md-7 emp-text-mod-dois">
							<h2 class="featurette-heading"> Pizza dois.</h2>
							<p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
						
						 <a href="https://api.whatsapp.com/send?phone=+5587999181877&text=Oi! Gostaria de Fazer Um Pedido!!" class="btn btn-success btn-icon-split" target="_blank">
				<span class="icon text-white-50">
					<i class="fab fa-whatsapp"></i>
				</span>
				<span class="text">Pedido Por WhatsApp</span>
			   </a>
						
						
						</div>
						<div class="col-md-5 emp-img-mod-dois">
							<img class="featurette-image img-fluid mx-auto" src="imagens/sob_card/2/02.jpg" alt="Generic placeholder image">
						</div>
					</div>
				</div>
			</div>
			
			<div class="jumbotron sobre-empresa">
				<div class="container">
					<div class="row featurette">
						<div class="col-md-7 order-md-2 emp-text-mod-um">
							<h2 class="featurette-heading">Pizza três.</h2>
							<p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
						
						 <a href="https://api.whatsapp.com/send?phone=+5587999181877&text=Oi! Gostaria de Fazer Um Pedido!!" class="btn btn-success btn-icon-split" target="_blank">
				<span class="icon text-white-50">
					<i class="fab fa-whatsapp"></i>
				</span>
				<span class="text">Pedido Por WhatsApp</span>
			   </a>
						
						
						</div>
						<div class="col-md-5 order-md-1 emp-img-mod-um">
							
							<img class="featurette-image img-fluid mx-auto" src="imagens/sob_card/3/03.jpg" alt="Generic placeholder image">
						
						</div>
					</div>
				</div>
			</div>
			
			<div class="jumbotron sobre-empresa">
				<div class="container">
					<div class="row featurette">
						<div class="col-md-7 emp-text-mod-dois">
							<h2 class="featurette-heading">Pizza quatro.</h2>
							<p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
						
						
						 <a href="https://api.whatsapp.com/send?phone=+5587999181877&text=Oi! Gostaria de Fazer Um Pedido!!" class="btn btn-success btn-icon-split" target="_blank">
				<span class="icon text-white-50">
					<i class="fab fa-whatsapp"></i>
				</span>
				<span class="text">Pedido Por WhatsApp</span>
			   </a>
						
						
						
						</div>
						<div class="col-md-5 emp-img-mod-dois">
							<img class="featurette-image img-fluid mx-auto" src="imagens/sob_card/4/04.jpg" alt="Generic placeholder image">
						</div>
					</div>
				</div>
			</div>
		</main>
		
				
	   <?php
       include_once 'footer.php';
       ?>


		<script src="js/jquery-3.2.1.slim.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/scrollreveal.min.js"></script>
		
		<script> 
			window.sr = ScrollReveal({ reset: true });
			sr.reveal('.emp-text-mod-um', { 
				duration: 1000,
				origin: 'rigth',
				distance: '20px'
			}); 	
			sr.reveal('.emp-img-mod-um', { 
				duration: 1000,
				origin: 'left',
				distance: '20px'
			}); 		
			sr.reveal('.emp-text-mod-dois', { 
				duration: 1000,
				origin: 'left',
				distance: '20px'
			}); 	
			sr.reveal('.emp-img-mod-dois', { 
				duration: 1000,
				origin: 'right',
				distance: '20px'
			}); 		
		</script>
  </body>
</html>