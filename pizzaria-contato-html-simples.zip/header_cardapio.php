<header>
			<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-warning">
				<div class="container">
					<a class="navbar-brand" href="index.php">Pizzaria</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarCollapse">
						<ul class="navbar-nav mr-auto">
							<li class="nav-item menu">
								<a class="nav-link" href="index.php">Home </a>
							</li>
							
							
							<li class="nav-item menu">
								<a class="nav-link" href="cardapio.php">Cardápio</a>
							</li>
							<li class="nav-item menu">
								<a class="nav-link" href="index#contato">Contato</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</header>
		