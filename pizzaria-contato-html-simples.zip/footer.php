<footer class="footer bg-warning">
			<div class="container text-center">
				© copyright Domingos Filho Desenvolvedor Web - 2022
			</div>
		</footer>